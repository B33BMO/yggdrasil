export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { db, save } from "../../../_store";

// Read current + all available policies (used by the modal)
export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const c = db.customers.find(x => x.id === id);
  if (!c) return NextResponse.json({ error: "customer not found" }, { status: 404 });
  return NextResponse.json({ policyIds: c.policyIds ?? [], available: db.policies });
}

// Replace the entire set (idempotent)
export async function PUT(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const c = db.customers.find(x => x.id === id);
  if (!c) return NextResponse.json({ error: "customer not found" }, { status: 404 });

  const body = await req.json().catch(() => ({}));
  const incoming: string[] = Array.isArray(body?.policyIds) ? body.policyIds : [];

  // only keep IDs that exist in db.policies
  const validIds = new Set(db.policies.map(p => p.id));
  const filtered = incoming.filter(pid => validIds.has(pid));

  c.policyIds = filtered;

  // propagate to devices under this customer
  db.devices.filter(d => d.customerId === id).forEach(d => {
    d.policyIds = [...filtered];
  });

  save(); // persist to .data/db.json
  return NextResponse.json({ ok: true, policyIds: filtered });
}

// Optional granular add/remove (if any callers still use it)
export async function POST(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const c = db.customers.find(x => x.id === id);
  if (!c) return NextResponse.json({ error: "customer not found" }, { status: 404 });

  const { policyId, action } = await req.json().catch(() => ({}));
  if (!db.policies.some(p => p.id === String(policyId))) {
    return NextResponse.json({ error: "unknown policy" }, { status: 400 });
  }

  const set = new Set(c.policyIds ?? []);
  if (action === "add") set.add(policyId);
  if (action === "remove") set.delete(policyId);
  c.policyIds = Array.from(set);

  db.devices.filter(d => d.customerId === id).forEach(d => { d.policyIds = [...c.policyIds]; });

  save();
  return NextResponse.json({ ok: true, policyIds: c.policyIds });
}
