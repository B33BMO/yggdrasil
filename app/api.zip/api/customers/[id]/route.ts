export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { db, save } from "../../_store";

export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  const exists = db.customers.some(c => c.id === id);
  if (!exists) return NextResponse.json({ error: "customer not found" }, { status: 404 });

  db.customers = db.customers.filter(c => c.id !== id);
  db.devices.forEach(d => {
    if (d.customerId === id) { d.customerId = undefined; d.policyIds = []; }
  });
  save();
  return new NextResponse(null, { status: 204 });
}
