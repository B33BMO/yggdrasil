export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { db } from "../../../_store";

export async function GET(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;

  // In this demo, agentId === deviceId (adjust if you map them differently)
  const dev = db.devices.find(d => d.id === id);
  if (!dev) return NextResponse.json({ agent_id: id, policies: [] });

  const pols = dev.policyIds
    .map(pid => db.policies.find(p => p.id === pid))
    .filter(Boolean)
    .map(p => ({
      id: p!.id,
      name: p!.name,
      yaml: toYaml(p!)
    }));

  return NextResponse.json({ agent_id: id, policies: pols });
}

function toYaml(p: any): string {
  // minimal YAML synthesis; expand as needed
  const header = [
    "policy:",
    `  id: ${p.id}`,
    `  name: ${p.name}`,
    `  version: ${p.version ?? 1}`,
    "",
    "rules:",
  ];
  const rules = [
    `  - id: ${p.id}-bash`,
    `    type: bash`,
    `    code: ""`,
  ];
  return [...header, ...rules, ""].join("\n");
}
