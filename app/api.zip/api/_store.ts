// app/api/_store.ts
// Simple JSON-backed store with atomic writes + debounce.
// Works in the Node runtime (be sure your route files export `runtime = "nodejs"`).

import fs from "fs";
import path from "path";

// ---- Types ----
export type TokenInfo = {
  token: string;
  customerId?: string;
  os?: string;
  used: boolean;
  createdAt: number;
};

export type Customer = { id: string; name: string; policyIds: string[] };

export type Device = {
  id: string;
  hostname: string;
  customerId?: string;
  distro: string;
  agentVersion: string;
  lastSeen: string;
  policyIds: string[];
};

export type Policy = { id: string; name: string; description?: string; version?: number };

type DB = {
  customers: Customer[];
  devices: Device[];
  policies: Policy[];
  // agentId -> deviceId mapping (optional; keep if you use it)
  agentMap: Record<string | number, string>;
  // simple counters/ids if you need them
  seq: { device: number; agent: number };
  // issued enrollment tokens (one-time use)
  tokens: Record<string, TokenInfo>;
};

// ---- File paths ----
const DATA_DIR = process.env.DATA_DIR ?? path.join(process.cwd(), ".data");
const DB_FILE = path.join(DATA_DIR, "db.json");
const TMP_FILE = DB_FILE + ".tmp";

// ---- Seed (only used on first run) ----
function seedPolicies(): Policy[] {
  return [
    { id: "pol-ufw-enable", name: "UFW Enable" },
    { id: "pol-ssh-baseline", name: "SSH Baseline" },
  ];
}

function defaultDb(): DB {
  return {
    customers: [],
    devices: [],
    policies: seedPolicies(),
    agentMap: {},
    seq: { device: 1, agent: 1 },
    tokens: {},
  };
}

// ---- Load once (sync) with backfill for new fields ----
function load(): DB {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(DB_FILE)) {
    const fresh = defaultDb();
    fs.writeFileSync(DB_FILE, JSON.stringify(fresh, null, 2));
    return fresh;
  }
  try {
    const raw = fs.readFileSync(DB_FILE, "utf8");
    const parsed = JSON.parse(raw) as Partial<DB>;
    const base = defaultDb();
    // Backfill any missing keys so older files keep working
    return {
      ...base,
      ...parsed,
      customers: parsed.customers ?? base.customers,
      devices: parsed.devices ?? base.devices,
      policies: parsed.policies ?? base.policies,
      agentMap: parsed.agentMap ?? base.agentMap,
      seq: parsed.seq ?? base.seq,
      tokens: parsed.tokens ?? base.tokens,
    };
  } catch (e) {
    console.error("[store] failed to read db.json, starting fresh:", e);
    const fresh = defaultDb();
    fs.writeFileSync(DB_FILE, JSON.stringify(fresh, null, 2));
    return fresh;
  }
}

// In-memory image (kept in sync with file via debounced writes)
export const db: DB = load();

// ---- Debounced atomic save ----
let timer: NodeJS.Timeout | null = null;
function writeNow() {
  try {
    fs.writeFileSync(TMP_FILE, JSON.stringify(db, null, 2));
    fs.renameSync(TMP_FILE, DB_FILE); // atomic on POSIX
  } catch (e) {
    console.error("[store] write error:", e);
  }
}

export function save(immediate = false) {
  if (immediate) {
    if (timer) clearTimeout(timer);
    timer = null;
    writeNow();
    return;
  }
  if (timer) clearTimeout(timer);
  timer = setTimeout(writeNow, 150); // coalesce bursts of writes
}

// Optional helpers to generate IDs
export function nextDeviceId(): number {
  const v = db.seq.device++;
  save(); // persist counter bump
  return v;
}
export function nextAgentId(): number {
  const v = db.seq.agent++;
  save();
  return v;
}
