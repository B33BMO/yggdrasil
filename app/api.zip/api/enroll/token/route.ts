export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { db, save } from "../../_store";

export async function POST(req: Request) {
  const { customerId, os } = await req.json().catch(() => ({} as any));
  const token = `enr_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;

  db.tokens[token] = {
    token,
    customerId,
    os,
    used: false,
    createdAt: Date.now(),
  };
  save();

  return NextResponse.json({ token, customerId, os }, { status: 201 });
}
