export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { db, save, nextDeviceId } from "../_store";

export async function POST(req: Request) {
  const { token, api, hostname, distro, customerId } = await req.json();

  // token optional validation
  const t = token ? db.tokens?.[token] : undefined;
  if (token) {
    if (!t) return NextResponse.json({ error: "invalid token" }, { status: 400 });
    if (t.used) return NextResponse.json({ error: "token already used" }, { status: 409 });
  }

  const id = String(nextDeviceId());
  const custId = customerId || t?.customerId;
  const cust   = custId ? db.customers.find(c => c.id === custId) : undefined;

  db.devices.push({
    id,
    hostname: hostname || `host-${id}`,
    customerId: custId || undefined,
    distro: String(distro || t?.os || "unknown"),
    agentVersion: "0.2.0",
    lastSeen: new Date().toISOString(),
    policyIds: cust?.policyIds ? [...cust.policyIds] : [],
  });

  // keep a mapping (optional)
  db.agentMap[id] = id;

  if (t) t.used = true;

  save(); // <- persist

  return NextResponse.json({ agent_id: id, device_id: id, api }, { status: 201 });
}
