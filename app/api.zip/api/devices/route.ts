export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { db, save, nextDeviceId } from "../_store";

export async function POST(req: Request) {
  const { hostname, customerId, distro } = await req.json();
  const id = String(nextDeviceId());
  const cust = db.customers.find(c => c.id === customerId);
  const policyIds = cust?.policyIds ? [...cust.policyIds] : [];

  db.devices.push({
    id,
    hostname: hostname || `host-${id}`,
    customerId: customerId || undefined,
    distro: String(distro || "unknown"),
    agentVersion: "0.2.0",
    lastSeen: new Date().toISOString(),
    policyIds,
  });
  save();
  return NextResponse.json({ id }, { status: 201 });
}
