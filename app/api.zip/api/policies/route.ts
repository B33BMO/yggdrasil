export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { db, save } from "../_store";

// simple slug from a name
function slugify(s: string) {
  return s.toLowerCase().trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 64);
}

export async function GET() {
  return NextResponse.json(db.policies);
}

/**
 * Create a policy.
 * Accepts flexible payloads:
 * {
 *   id?: string;           // optional, will be generated from name if omitted
 *   name?: string;         // recommended
 *   description?: string;  // optional
 *   packageName?: string;  // optional (for “install package” style)
 *   args?: string;         // optional args string
 *   bash?: string;         // optional bash script
 * }
 */
export async function POST(req: Request) {
  const body = await req.json().catch(() => ({} as any));

  // derive a friendly name if not provided
  const name: string | undefined =
    body?.name ??
    (body?.packageName ? `Install ${String(body.packageName)}` : undefined) ??
    (body?.bash ? "Custom Bash" : undefined);

  if (!name) {
    return NextResponse.json({ error: "name (or packageName/bash) is required" }, { status: 400 });
  }

  // id: provided or generated from name
  let id: string = String(body?.id || "").trim();
  if (!id) id = `pol-${slugify(name)}`;

  if (db.policies.some(p => p.id === id)) {
    return NextResponse.json({ error: "policy id already exists" }, { status: 409 });
  }

  const policy = {
    id,
    name,
    description: body?.description ?? "",
    // keep extra fields if you want to evolve later (harmless to store)
    packageName: body?.packageName,
    args: body?.args,
    bash: body?.bash,
    version: 1,
  } as any;

  db.policies.push(policy);
  save();

  return NextResponse.json(policy, { status: 201 });
}
