export const runtime = "nodejs";

import { NextResponse } from "next/server";
import { db, save } from "../../_store";

export async function POST(req: Request) {
  const body = await req.json().catch(() => ({}));
  // agent_id can be number or string depending on your agent
  const agentIdRaw = body?.agent_id;
  const agentId = agentIdRaw != null ? String(agentIdRaw) : "";

  let deviceId: string | undefined;

  // Support both Map-like and object-like agentMap, then fallback
  const mapAny: any = (db as any).agentMap;
  if (mapAny && typeof mapAny.get === "function") {
    deviceId = mapAny.get(agentId) ?? mapAny.get(Number(agentId));
  } else {
    deviceId = (db.agentMap as any)[agentId] ?? (db.agentMap as any)[Number(agentId)];
  }
  if (!deviceId) deviceId = agentId; // fallback: in this demo agent_id === device_id

  // Update lastSeen if we find the device
  const dev = db.devices.find(d => String(d.id) === String(deviceId));
  if (dev) {
    dev.lastSeen = new Date().toISOString();
    // (Optional) store results if you send them:
    // dev.lastResult = body?.result ?? null;
    save();
  }

  return NextResponse.json({ ok: true });
}
